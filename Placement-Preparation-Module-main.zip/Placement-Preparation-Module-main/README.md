# Placement-Preparation-Module
Prateek Kumar
2100290109013
CSE Sec C
7th Semester
